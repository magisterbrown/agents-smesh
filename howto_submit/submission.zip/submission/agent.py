import numpy as np

def agent(state):
    return 0
